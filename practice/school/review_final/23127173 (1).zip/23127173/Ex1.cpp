#include<iostream>
#include<queue>
#include<vector>

using namespace std;

struct Node{
	int data;
	int height;
	Node* left;
	Node* right;
};

typedef Node* node;

node make_node(int data){
	node tmp = new Node();
	tmp->data = data;
	tmp->left = NULL;
	tmp->right = NULL;
	
	return tmp;
}

node insert(node root, int data){
	if(root == NULL){
		return make_node(data);
	}
	
	if(data < root->data) root->left = insert(root->left, data);
	else if(data > root->data) root->right = insert(root->right, data);
	
	return root;
}

void LNR(node root){
	if(!root) return;
	
	LNR(root->left);
	cout << root->data << " ";
	LNR(root->right);
}

int depth(node root, int k){
	if(root == NULL) return 0;
	
	queue<node> qu;
	qu.push(root);
	
	int h = 0;
	int res;
	
	while(!qu.empty()){
		
		int size = qu.size();
		h++;
		
		while(size--){
			node tmp = qu.front();
			
			if(tmp->data == k){
				res = h;
//				a.push_back(tmp->data);
			}

//			cout << h << " ";
//			cout << tmp->data << " ";
			
			qu.pop();
			
			if(tmp->left) qu.push(tmp->left);
			if(tmp->right) qu.push(tmp->right);
		}
		
//		cout << endl;
	}
	
	return res;
}

// dua cac node cung level vao vector a
void search(node root, node cur, vector<int> &a, int deep){	
	if(root == NULL) return;
	
//	cout << 1;
	search(root, cur->left, a, deep);
	
	int t = depth(root, cur->data); 
//	cout << t << " ";
	if(t == deep) a.push_back(cur->data);
	
	
	search(root, cur->right, a, deep);
}

int main(){
	
	int n, k;
	cin >> n >> k;
	
	node root = NULL;
	
	for(int i = 0; i < n; i++){
		int data; cin >> data;
		root = insert(root, data);
	}
	
//	LNR(root);

	int deep = depth(root, k);
//	cout << deep;

	vector<int> a;
	a.clear();
	
	node cur = root;
	search(root, cur, a, deep);
	
//	for(int i = 0; i < a.size(); i++){
//		cout << a[i] << " ";
//	}
//	
//	cout << a.size();	
	
//	truong hop depth do chi co k
	if(a.size() == 1){
		cout << "null"; 
	} else {
		int j = 0;
		for(int i = 0; i < a.size(); i++){
			if(a[i] == k){
				j = i;
			}
		}
		// neu k nam o cuoi cung
		if(j == a.size() - 1){
			cout << "null";
		} else {
			// nguoc lai thi in ra sibling ben phai
			cout << a[j + 1]; 
		}
	} 
	
	return 0;
}
