#include<iostream>
#include<vector>
#include<queue>

using namespace std;

int BFS(const vector<vector<int> > &list, int S, int D, vector<bool> &visited){
	queue<int> qu;
	
	qu.push(S);
	visited[S] = true;
	
	int cnt = 0;
	
	while(!qu.empty()){
		int tmp = qu.front();
		visited[tmp] = true;
		
		if(tmp == D){
			cnt++;
			visited[D] = false;
		} 
		else qu.pop();

		
		for(int i = 0; i < list[tmp].size(); i++){
			if(!visited[i]){
				qu.push(list[tmp][i]);
//				visited[i] = true;
			}
		}	
	}
	
	return cnt;
}

int main(){
	
	int V, E, S, D;
	cin >> V >> E >> S >> D;
	
	vector< vector<int> > list(V);
	for(int i = 0; i < E; i++){
		int u, v;
		cin >> u >> v;
		list[u].push_back(v);
	}

	vector<bool> visited(E, false);
	cout << BFS << " ";
	
	return 0;
}
